
<?php
error_reporting(E_ALL & ~E_NOTICE);
$dbhost="localhost";
$dbusername="root";
$dbpassword="eKuCfB]N";
$dbname="voting";


$db=mysqli_connect($dbhost,$dbusername,$dbpassword,$dbname);
if (!$db) {
	die("Connection Failed: ".mysqli_connect_error());
}
?>
