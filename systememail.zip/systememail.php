<?php
//$systememail="EMAIL_NAME";
//$systempassword="EMAIL_PASSWORD";

$systememail= "Evoting@kuis.edu.my";
$systempassword= "evotingkuis";

?>
